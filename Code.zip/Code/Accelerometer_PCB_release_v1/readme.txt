This is the sketch that makes up all the accelerometer code.
Upload and run on your Arduino-accelerometer logger :)