This sketch is a stand-alone program used to set the time on the DS3231 RTC-board.
Instructions are available over the serial monitor when the code is running. 

To set the time, send values to change one-by-one over the serial monitor.
For example: y 2018
to set the year to 2018, the format is: 'codeword *space* value'

Codewords:
y - year
mo - month
d - day
h - hour
mi - minute
s - second

the codewords are all lower case.